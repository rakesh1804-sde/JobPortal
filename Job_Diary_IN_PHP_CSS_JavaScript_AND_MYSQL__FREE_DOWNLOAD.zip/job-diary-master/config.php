
<?php
date_default_timezone_set('Asia/Kolkata');
$username="root";
$password="";
$server="localhost";
$db="yasheka";
$con=new mysqli($server,$username,$password,$db);
?>
