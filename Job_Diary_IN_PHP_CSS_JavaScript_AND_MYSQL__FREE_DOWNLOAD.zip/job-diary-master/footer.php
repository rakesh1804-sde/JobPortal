<html>
<body>
<footer>
<div class="container-fluid">
<div class="row footer-top">
<div class="col-lg-3 footer-about-us">
<h3>About job dairy</h3>
<p>Sudden looked elinor off gay estate nor silent. Son read such next see the rest two. Was use extent old entire sussex..</p>
<a href="" class="thm-inverse">Read More</a>
</div>
<div class="col-lg-3 footer-quick-links">
<h3>Quick Links</h3>
<ul>
<li><a href="">Browse Jobs</a></li>
<li><a href="">Viem Employers</a></li>
<li><a href="">Post a Job</a></li>
<li><a href="">Submit Resume</a></li>
</ul>
</div>
<div class="col-lg-3 footer-address">
<h3>Find Us</h3>
<p>9870 St Vincent Place,</p>
<p>Glasgow, DC 45 Fr 45.</p>
<p>Freephone: +1 800 559 6580</p>
<p>mail@demolink.org</p>

</div>
<div class="col-lg-3 footer-subscribe">
<h3>Contact us</h3>
<p>Subscribe to get our latest updates and offers.</p>
<input type="email" name="subscribe" placeholder="Enter Your Email ID"/><button type="submit"><span class="glyphicon glyphicon-envelope"></span></button>
<p>***Don't worry, we wont spam you!</p>
</div>
</div>
<div class="row footer-bottom">
<p>copyrights &copy; <?php echo date("Y"); ?> Job Dairy</p>
</div>
</div>
</footer>
</body>
</html>
