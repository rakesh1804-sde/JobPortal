<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<link href="_img/owlphin_log.png" rel="icon">

<link rel="stylesheet" href="_css/_strap.min.css">
<link rel="stylesheet" href="_css/_fa.css">
<link href="_css/_owlphin.css" rel="stylesheet">
<link href="_css/_responsive.css" rel="stylesheet">
<link href="_css/_rcrop.css" media="screen" rel="stylesheet" type="text/css">

<script src="_js/_preloader.js"></script>