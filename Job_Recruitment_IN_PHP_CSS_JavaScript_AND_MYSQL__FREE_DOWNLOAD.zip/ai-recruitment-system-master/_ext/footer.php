<div class="footer-inner">
    <div class="container">
      <div class="row">
        <div class="span12"> 
		&copy; 2018 <a href="javascript:void(0)" onclick="owlphinhome()">Bacsyd</a>.
		<span class="strict-mobile-no-visibility">|  <a href="javascript:void(0)" onclick="contact()">Contact us</a>
		|  <a href="javascript:void(0)" onclick="help()">Help</a>
		|  <a href="javascript:void(0)" onclick="admin()">Admin</a></span>
		</div>
      </div>
    </div>
  </div>