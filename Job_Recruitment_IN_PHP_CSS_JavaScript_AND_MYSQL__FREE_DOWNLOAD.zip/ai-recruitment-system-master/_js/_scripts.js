//function initializeJS() {jQuery("html").niceScroll({styler:"fb",cursorcolor:"#8f8f8f", cursorwidth: '6', cursorborderradius: '10px', background: 'transparent', cursorborder: '', zindex: '1000'});}
//jQuery(document).ready(function(){initializeJS();});

/*$(document).on("keyup",'[data-action="grow"]',function(){$(window).width()>1e3&&$(this).animate({width:415})});
 $(document).on("blur",'[data-action="grow"]',function(){if($(window).width()>1e3){$(this).animate({width:200})}}); */